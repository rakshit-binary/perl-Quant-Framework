package Quant::Framework;

use strict;
use warnings;

our $VERSION = '0.11';

=head1 NAME

Quant::Framework - Gateway to fetch market-data from Quant::Framework 

=head1 VERSION

0.11

=head1 SYNOPSYS


=head1 DESCRIPTION

=cut
